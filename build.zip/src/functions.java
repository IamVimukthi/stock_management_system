
public interface functions {
    
    public abstract void add();
    
    
    public abstract void deleterecords();
    
    
}
